<ul id="album-gallery">
	<?php foreach( $albums as $album ) : ?>
		<li>
			<img src="<?php esc_attr_e( $album[ 'thumbnail' ] ); ?>" alt="<?php esc_attr_e( $album[ 'title' ] ); ?>" />
			<?php esc_html_e( $album[ 'title' ] ); ?>
		</li>
	<?php endforeach; ?>
</ul>