<?php if( $section[ 'id' ] == WordPressPluginSkeleton::PREFIX . 'section-basic' ) : ?>
	
	<p>Example section introduction.</p>
	
<?php elseif( $section[ 'id' ] == WordPressPluginSkeleton::PREFIX . 'section-advanced' ) : ?>
	
	<p>Another example section introduction.</p>
	
<?php endif; ?>