<ul>
	<li>foo: <?php esc_attr_e( $attributes[ 'foo' ] ); ?></li>
	<li>bar: <?php esc_attr_e( $attributes[ 'bar' ] ); ?></li>
</ul>