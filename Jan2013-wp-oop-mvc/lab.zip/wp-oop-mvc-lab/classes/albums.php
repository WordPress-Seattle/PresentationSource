<?php

// @todo load into main controller

class Albums	// @todo inherit from base module, implement custom post type interface
{
	const POST_TYPE_NAME	= 'Album';
	const POST_TYPE_SLUG	= 'album';
	const TAG_NAME			= 'Genre';
	const TAG_SLUG			= 'genre';
	
	/*
	 * Abstract methods from WPPSModule that we need to define
	 */
	
	// @mvc Controller
	protected function __construct()
	{
		// @todo register hook callbacks
	}
		
	// @mvc Controller
	public function activate( $networkWide )
	{
	}

	// @mvc Controller
	public function deactivate()
	{
	}
	
	// @mvc Controller
	public function registerHookCallbacks()
	{
		add_action( 'init',					__CLASS__ . '::createPostType' );
		add_shortcode( 'album-gallery',		__CLASS__ . '::albumGalleryShortcode' );
	}
	
	// @mvc Controller
	public function init()
	{
	}

	// @mvc Controller
	public function upgrade( $dbVersion = 0 )
	{
	}
	
	// @mvc Model
	protected function isValid( $property = 'all' )
	{
	}
	
	
	
	/*
	 * Methods from the WPPSCustomPostType interface that we need to define
	 */
	
	// @mvc Controller
	public static function createPostType()
	{
		register_post_type( self::POST_TYPE_SLUG, self::getPostTypeParams() );
	}

	// @mvc Model
	protected static function getPostTypeParams()
	{
		$labels = array
		(
			'name'					=> self::POST_TYPE_NAME . 's',
			'singular_name'			=> self::POST_TYPE_NAME,
			'add_new'				=> 'Add New',
			'add_new_item'			=> 'Add New '. self::POST_TYPE_NAME,
			'edit'					=> 'Edit',
			'edit_item'				=> 'Edit '. self::POST_TYPE_NAME,
			'new_item'				=> 'New '. self::POST_TYPE_NAME,
			'view'					=> 'View '. self::POST_TYPE_NAME . 's',
			'view_item'				=> 'View '. self::POST_TYPE_NAME,
			'search_items'			=> 'Search '. self::POST_TYPE_NAME . 's',
			'not_found'				=> 'No '. self::POST_TYPE_NAME .'s found',
			'not_found_in_trash'	=> 'No '. self::POST_TYPE_NAME .'s found in Trash',
			'parent'				=> 'Parent '. self::POST_TYPE_NAME
		);

		$postTypeParams = array(
			'labels'				=> $labels,
			'singular_label'		=> self::POST_TYPE_NAME,
			'public'				=> true,
			'menu_position'			=> 20,
			'hierarchical'			=> true,
			'capability_type'		=> 'post',
			'has_archive'			=> true,
			'rewrite'				=> array( 'slug' => self::POST_TYPE_SLUG, 'with_front' => false ),
			'query_var'				=> true,
			'supports'				=> array( 'title', 'editor', 'author', 'thumbnail', 'revisions' )
		);
		
		return $postTypeParams;
	}

	// @mvc Controller
	public static function createTaxonomies()
	{
	}
	
	// @mvc Controller
	public static function addMetaBoxes()
	{
	}

	// @mvc Controller
	public static function markupMetaBoxes( $post, $box )
	{
	}

	// @mvc Controller
	public static function savePost( $postID, $revision )
	{
	}
	
	// @mvc Controller
	public static function albumGalleryShortcode( $attributes )
	{
		// @todo get albums, capture view in buffer, return
	}
	
	// @mvc Model
	protected static function getAlbumsForGallery()
	{
		$albums = get_posts( array(
			'post_type'		=> self::POST_TYPE_SLUG,
			'numberposts' => '-1'
		) );
		
		foreach( $albums as &$album )
		{
			$featuredImageID = get_post_thumbnail_id( $album->ID );
			
			$album = array(
				'title'		=> get_the_title( $album->ID ),
				'thumbnail'	=> $featuredImageID ? wp_get_attachment_thumb_url( $featuredImageID ) : 'http://placehold.it/150x150'
			);
		}
	
		return $albums;
	}
}